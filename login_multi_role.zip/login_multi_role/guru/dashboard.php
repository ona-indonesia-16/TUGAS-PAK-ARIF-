
<?php
session_start();
require_once '../config/koneksi.php';

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['role'])) {
    header("Location: ../auth/login.php");
    exit;
}

// Memastikan hanya admin yang bisa masuk
if ($_SESSION['role'] != 'guru') {
    die("Akses ditolak! Anda bukan guru.");
}

// Mengambil data pengguna dari database
$id = (int) $_SESSION['id'];

$stmt = mysqli_prepare(
    $conn,
    "SELECT nama, username, email, role
     FROM users WHERE id = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result(
    $stmt, $nama, $username, $email, $role
);

if (!mysqli_stmt_fetch($stmt)) {
    http_response_code(404);
    exit("Data pengguna tidak ditemukan.");
}

mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <style>
        
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background: #f1f5f9;
    color: #1e293b;
}

.container {
    width: 90%;
    max-width: 800px;
    margin: 50px auto;
}

.card {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 12px #00000015;
    margin-bottom: 20px;
}

h1, h2 {
    color: #1d4ed8;
    margin-bottom: 15px;
}

p {
    margin-bottom: 12px;
    line-height: 1.6;
}

.profile-row {
    padding: 12px 0;
    border-bottom: 1px solid #e2e8f0;
    overflow-wrap: anywhere;
}

.btn {
    display: inline-block;
    background: #2563eb;
    color: white;
    padding: 11px 18px;
    border: none;
    border-radius: 6px;
    text-decoration: none;
    cursor: pointer;
    margin-top: 15px;
}

.btn:hover {
    background: #1d4ed8;
}

.logout {
    background: #dc2626;
}

.logout:hover {
    background: #b91c1c;
}
</style>

<div class="container">
    <div class="card">
        <h1>Dashboard Guru</h1>
        <p>Selamat datang,
            <?= htmlspecialchars($nama) ?>!
        </p>
        <p>Anda berhasil login sebagai Guru.</p>
    </div>

    <div class="card">
        <h2>Profil Pengguna</h2>

        <div class="profile-row">
            <strong>Nama:</strong>
            <?= htmlspecialchars($nama) ?>
        </div>

        <div class="profile-row">
            <strong>Username:</strong>
            <?= htmlspecialchars($username) ?>
        </div>

        <div class="profile-row">
            <strong>Email:</strong>
            <?= htmlspecialchars($email) ?>
        </div>

        <div class="profile-row">
            <strong>Role:</strong>
            <?= htmlspecialchars($role) ?>
        </div>

        <br>
        <a class="btn logout" href="../auth/logout.php">
            Logout
        </a>
    </div>
</div>

</body>
</html>
