<?php
$host = "localhost";
$user = "root";       // Default Laragon/XAMPP adalah root
$password = "";       // Default Laragon/XAMPP adalah kosong
$database = "db_login";
// Membuat koneksi
$conn = mysqli_connect($host, $user, $password, $database);
// Mengecek koneksi
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

//echo "Koneksi database berhasil!";

?>