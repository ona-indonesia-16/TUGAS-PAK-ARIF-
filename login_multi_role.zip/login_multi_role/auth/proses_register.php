<?php

require_once '../config/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["ngaran"];
    $username = $_POST["user"];
    $email = $_POST["mail"];
    $password = $_POST["pw"];
    $konfirmasi = $_POST["kon_pw"];
    $role = $_POST["role"];

    if ($password !== $konfirmasi) {
        echo "<script>alert('Password dan Konfirmasi tidak cocok!'); window.location='register.php'";
        exit;
    }

    $cek_user = mysqli_query($conn, "SELECT * FROM users WHERE username = '$username' OR email= '$email'");
    if (mysqli_num_rows($cek_user) > 0) {
        echo "<script>alert ('username atau email sudah terdaftar!'); window.location='register.php'</script>";
        exit;
    }

     // 3. HASH PASSWORD (PENTING KEMANAN!)
    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

     // 4. Simpan ke database
    $query = "INSERT INTO users (nama, username, email, password, role) 
              VALUES ('$nama', '$username', '$email', '$password_hashed', '$role')";
    if (mysqli_query($conn, $query)) {
         echo "<script>alert('Registrasi Berhasil! Silakan Login.'); window.location='login.php'</script>";
         } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>